---
name: mastergo-pangu-spacing
description: MasterGo 插件——盘古之白（中英文间距）。当用户需要在 MasterGo 设计稿中自动处理中英文混排间距、为中文与英文/数字边界添加视觉间距、或开发/调试该插件时使用。插件通过 letterSpacing 在边界字符上设置字号 ÷ 6 的间距，不插入空格字符，不改变文字内容，并排除货币符号（￥$€等）与数字之间的间距。
---

# MasterGo 插件：盘古之白（中英文间距）

## 插件简介

**盘古之白**是一个 MasterGo 设计工具插件，实现了"盘古间距"规范：在中文与英文/数字的边界处自动添加视觉间距，提升中英文混排的可读性。

### 核心特性

- **非破坏性**：通过 `letterSpacing`（字符间距）实现，不插入空格字符，不改变文字内容
- **精准间距**：间距宽度 = 字号 ÷ 6（PIXELS 单位），与字号自适应
- **智能排除**：货币符号（￥、$、€、£、¥、₩ 等）紧跟数字时不加间距（如 ￥100、$99）
- **灵活范围**：支持处理「当前选中图层」「当前页面」「全部页面」三种范围
- **进度反馈**：实时显示处理进度和结果统计

---

## 插件文件结构

```
pangu-spacing-plugin/
├── manifest.json   # 插件声明文件
├── main.js         # 主线程逻辑（间距处理核心）
└── ui.html         # 插件 UI 界面
```

---

## 导入 MasterGo 的步骤

1. 打开 MasterGo 桌面客户端
2. 菜单 → **插件** → **开发** → **导入插件**
3. 选择 `pangu-spacing-plugin/manifest.json` 文件
4. 插件出现在插件列表后，点击运行即可

---

## 技术实现说明

### 字符类型判断

```javascript
// CJK 字符范围（中日韩及相关符号）
var CJK_RANGES = [
  [0x2e80, 0x2eff], [0x2f00, 0x2fdf], [0x3040, 0x309f], [0x30a0, 0x30ff],
  [0x3100, 0x312f], [0x3200, 0x32ff], [0x3400, 0x4dbf], [0x4e00, 0x9fff],
  [0xa960, 0xa97f], [0xac00, 0xd7ff], [0xf900, 0xfaff], [0xfe10, 0xfe1f],
  [0xfe30, 0xfe4f], [0xff00, 0xffef]
];

// 货币符号排除列表
var CURRENCY_SYMBOLS = {
  '￥': true, '¥': true, '$': true, '€': true,
  '£': true, '₩': true, '₪': true, '₫': true, '₹': true, '฿': true
};
```

### 间距设置逻辑

```javascript
// 给边界左侧字符设置 letterSpacing
var addPx = fontSize / 6;  // 间距 = 字号 ÷ 6
var newPx = origPx + addPx; // 叠加原有间距
node.setRangeLetterSpacing(idx, idx + 1, { value: newPx, unit: 'PIXELS' });
```

### 兼容性说明

- 使用 ES5 语法（Promise `.then()` 链，避免 `async/await`），兼容 MasterGo 沙箱环境
- 使用传统 `for` 循环，避免 `for...of` 在沙箱中的兼容问题
- 通过 `mg.document.currentPage` 访问当前页面（非 `mg.currentPage`）

---

## 使用场景示例

当用户说：
- "帮我处理设计稿里中英文混排的间距"
- "MasterGo 里中文和英文之间没有间距，看起来很挤"
- "盘古之白插件怎么用"
- "给设计稿加上中英文间距"

→ 引导用户将插件导入 MasterGo，选择处理范围后点击「开始处理」。

---

## 注意事项

1. **重复执行**：插件会在原有 `letterSpacing` 基础上叠加，重复执行会累加间距，建议先撤销再重新执行
2. **字体加载**：处理前会自动加载文本节点所用字体，若字体缺失可能跳过该节点
3. **API 版本**：基于 MasterGo Plugin API 1.0.0，如遇 API 变更请参考官方文档更新
